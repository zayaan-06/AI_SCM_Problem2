import pandas as pd
import numpy as np
import lightgbm as lgb
import os

def run_prediction_pipeline():
    print("🚀 Stage 2: Initializing Absolute Conformal Spread Engine with Location Identifiers...")
    
    # Step 1: Loading optimized parquet datasets
    print("Step 1: Ingesting high-performance parquet splits from disk...")
    X_train = pd.read_parquet('features_training.parquet')
    y_train = pd.read_parquet('sales_training.parquet')['units_sold']
    X_calib = pd.read_parquet('features_calibration.parquet')
    y_calib = pd.read_parquet('sales_calibration.parquet')['units_sold']
    X_test_raw = pd.read_parquet('features_testing.parquet')
    
    # 🌟 Read raw sales mapping labels to map string labels to code outputs
    print("   ↳ Extracting baseline string store names for output visibility...")
    raw_sales = pd.read_csv('sales_train_evaluation.csv', usecols=['store_id'])
    store_mapping = dict(enumerate(raw_sales['store_id'].astype('category').cat.categories))
    
    categorical_features = [
        'item_id', 'dept_id', 'cat_id', 'store_id', 'state_id', 'event_type_1',
        'holiday_cat_interaction', 'category_wday_interaction',
        'holiday_cat_lead_1', 'holiday_cat_lead_2'
    ]
    
    # Preserve numeric codes before category conversions for translation array maps
    test_store_codes = X_test_raw['store_id'].values
    
    # Force explicit conversion to category objects so LightGBM recognizes numerical codes
    for col in categorical_features:
        X_train[col] = X_train[col].astype('category')
        X_calib[col] = X_calib[col].astype('category')
        X_test_raw[col] = X_test_raw[col].astype('category')
    
    # Isolate structural day indices from active tree arrays
    X_train_fit = X_train.drop(columns=['day_int'])
    X_calib_fit = X_calib.drop(columns=['day_int'])
    X_test_fit = X_test_raw.drop(columns=['day_int'])
    
    print("\nStep 2: Training LightGBM point baseline and asymmetric quantile heads...")
    model_base = lgb.LGBMRegressor(objective='regression', n_estimators=100, learning_rate=0.06, random_state=42, n_jobs=-1, verbose=-1)
    model_base.fit(X_train_fit, y_train, categorical_feature=categorical_features)
    
    model_q05 = lgb.LGBMRegressor(objective='quantile', alpha=0.05, n_estimators=100, learning_rate=0.06, random_state=42, n_jobs=-1, verbose=-1)
    model_q05.fit(X_train_fit, y_train, categorical_feature=categorical_features)
    
    model_q95 = lgb.LGBMRegressor(objective='quantile', alpha=0.95, n_estimators=100, learning_rate=0.06, random_state=42, n_jobs=-1, verbose=-1)
    model_q95.fit(X_train_fit, y_train, categorical_feature=categorical_features)
    
    print("\nStep 3: Evaluating out-of-sample error properties on calibration pool...")
    calib_lower = np.clip(model_q05.predict(X_calib_fit), 0, None)
    calib_upper = np.clip(model_q95.predict(X_calib_fit), 0, None)
    calib_point = np.clip(model_base.predict(X_calib_fit), 0, None)
    
    # Calculate conformity scores using initial out-of-sample predictions
    conformity_scores = np.maximum(calib_lower - y_calib, y_calib - calib_upper)
    calib_widths = calib_upper - calib_lower
    calib_rel_scores = calib_widths / (calib_point + 1.0)
    
    # Stratified split partitions to secure error margin targets
    thresh_low = np.quantile(calib_rel_scores, 0.33)
    thresh_high = np.quantile(calib_rel_scores, 0.66)
    
    q_margins = {}
    target_coverage = 0.95
    
    low_mask = calib_rel_scores <= thresh_low
    mod_mask = (calib_rel_scores > thresh_low) & (calib_rel_scores <= thresh_high)
    high_mask = calib_rel_scores > thresh_high
    
    for tier, mask in [('Low Risk', low_mask), ('Moderate Risk', mod_mask), ('High Risk', high_mask)]:
        sub_scores = conformity_scores[mask]
        if len(sub_scores) > 0:
            q_level = np.clip(np.ceil((len(sub_scores) + 1) * target_coverage) / len(sub_scores), 0, 1)
            q_margins[tier] = np.quantile(sub_scores, q_level)
        else:
            q_margins[tier] = 0.0
            
    print(f"   ↳ Calibrated Low-Risk Cushion:      {q_margins['Low Risk']:.4f} units")
    print(f"   ↳ Calibrated Moderate-Risk Cushion:  {q_margins['Moderate Risk']:.4f} units")
    print(f"   ↳ Calibrated High-Risk Cushion:      {q_margins['High Risk']:.4f} units")

    print("\nStep 4: Compiling interval boundaries over the 41-day test horizon...")
    test_preds_point = np.clip(model_base.predict(X_test_fit), 0, None)
    test_preds_q05 = np.clip(model_q05.predict(X_test_fit), 0, None)
    test_preds_q95 = np.clip(model_q95.predict(X_test_fit), 0, None)
    
    test_preds_conf_lower, test_preds_conf_upper = [], []
    for i in range(len(test_preds_point)):
        score = (test_preds_q95[i] - test_preds_q05[i]) / (test_preds_point[i] + 1.0)
        tier = 'Low Risk' if score <= thresh_low else 'Moderate Risk' if score <= thresh_high else 'High Risk'
        test_preds_conf_lower.append(np.clip(test_preds_q05[i] - q_margins[tier], 0, None))
        test_preds_conf_upper.append(test_preds_q95[i] + q_margins[tier])
        
    test_preds_conf_lower = np.array(test_preds_conf_lower)
    test_preds_conf_upper = np.array(test_preds_conf_upper)
    
    print("\nStep 5: Partitioning Risk Tiers via Absolute Conformal Widths...")
    conformal_widths = test_preds_conf_upper - test_preds_conf_lower
    
    # Direct absolute quantile values
    w_thresh_low = np.quantile(conformal_widths, 0.33)
    w_thresh_high = np.quantile(conformal_widths, 0.66)
    
    print(f"   ↳ Absolute Width Splits: Low Risk <= {w_thresh_low:.1f} | High Risk > {w_thresh_high:.1f}")
    
    final_risk_tiers = []
    for w in conformal_widths:
        if w <= w_thresh_low:
            final_risk_tiers.append('Low Risk')
        elif w <= w_thresh_high:
            final_risk_tiers.append('Moderate Risk')
        else:
            final_risk_tiers.append('High Risk')
            
    # Translate original numerical arrays back into readable strings
    string_store_labels = [store_mapping[code] for code in test_store_codes]
            
    # Compile output table configuration
    results_df = pd.DataFrame({
        'day_number': X_test_raw['day_int'], 
        'store_id': string_store_labels,
        'item_number': X_test_raw['item_id'],
        'point_estimate': np.round(test_preds_point, 2),
        'raw_quantile_lower': np.round(test_preds_q05, 2), 
        'raw_quantile_upper': np.round(test_preds_q95, 2),
        'conformal_range_lower': np.round(test_preds_conf_lower, 2), 
        'conformal_range_upper': np.round(test_preds_conf_upper, 2),
        'risk_tier': final_risk_tiers
    })
    results_df.sort_values(by=['day_number', 'store_id', 'item_number'], inplace=True, ignore_index=True)
    results_df.to_csv('test_forecasting_results.csv', index=False)
    
    print("\n📊 Verification - Location Output Structure Sample:")
    print(results_df[['day_number', 'store_id', 'item_number', 'risk_tier']].head(5))
    print("\n   ↳ 📑 Master forecast table written safely with location context: 'test_forecasting_results.csv'")

if __name__ == "__main__":
    run_prediction_pipeline()